#include "derivationprinter.cc"
#include <vector>
#include <string>
#include <iostream>
#include <sstream>
// Use only the neeeded aspects of each namespace
using namespace std;

int recurse(int i){
  string line;
  getline(cin, line);
  line = trim(line);
  string checker;

  if (i == 0) {
    istringstream iss(line);
    iss >> checker;
    iss >> checker;

    if (checker == "expr") {
      return recurse(0) - recurse(1);
    }
    else {
      return recurse(1);
    }
  }
  else {
    istringstream iss(line);
    iss >> checker;
    iss >> checker;

    if (checker == "id") {
      return 42;
    }
    else {
      return recurse(0);
    }
  }
}


int main() {
  skipGrammar(std::cin);
  string extra;    // get rid of first line
  getline(cin, extra);

  cout << recurse(0) << endl;
}